// Vercel serverless function: GET /api/search?q=...
// Uses Google's own free Custom Search API (100 queries/day, no card needed)
// so results look and feel like real Google search results.

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const query = req.query.q

  if (!query || !query.trim()) {
    return res.status(400).json({ error: 'A search query ("q") is required.' })
  }

  const apiKey = process.env.GOOGLE_SEARCH_API_KEY
  const searchEngineId = process.env.GOOGLE_SEARCH_ENGINE_ID

  if (!apiKey || !searchEngineId) {
    return res.status(500).json({
      error: 'The server is missing GOOGLE_SEARCH_API_KEY or GOOGLE_SEARCH_ENGINE_ID. See README.md.',
    })
  }

  const url = new URL('https://www.googleapis.com/customsearch/v1')
  url.searchParams.set('key', apiKey)
  url.searchParams.set('cx', searchEngineId)
  url.searchParams.set('q', query)

  try {
    const response = await fetch(url)
    const data = await response.json()

    if (!response.ok) {
      return res.status(response.status).json({
        error: data.error?.message || 'The search service returned an error.',
      })
    }

    const results = (data.items || []).map((item) => ({
      title: item.title,
      link: item.link,
      displayLink: item.displayLink,
      snippet: item.snippet,
    }))

    return res.status(200).json({ results })
  } catch (err) {
    return res.status(500).json({ error: 'Could not reach the search service.' })
  }
}
